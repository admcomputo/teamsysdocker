export interface User {
  id: string;
  email: string;
  fullName: string;
  token: string;
  foto?: string;
  roles: string[];
}
